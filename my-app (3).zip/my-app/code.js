// Returns the name of a random breed of dog
// return {string} - the name of a random dog breed
function randomDogBreed(){
  var dogBreeds = getColumn("Dogs","Name");
  return (dogBreeds[randomNumber(0,dogBreeds.length-1)]);
}



// Returns the image of a given dog breed
// searchBreed {string} - the name of the breed to search for
function dogBreedImage(searchBreed){
  var dogBreeds    = getColumn("Dogs", "Name");
  var dogimages    = getColumn("Dogs", "Image");
  var image;
  
  for(var i=0; i<dogBreeds.length; i++){
    if(dogBreeds[i] == searchBreed){
      image = dogimages[i];
    }
  }
  
  return image;
}



// Returns the purpose of a given dog breed
// searchBreed {string} - the name of the breed to search for
function breedsPurpose(searchBreed) {
  var dogBreeds    = getColumn("Dogs", "Name");
  var dogsPurpose = getColumn("Dogs", "Bred For");
  var purpose;
  
  for (var i = 0; i < dogBreeds.length; i++) {
    if(dogBreeds[i] == searchBreed){
    purpose = dogsPurpose[i];
    }
  }
  
  return purpose;
}



// Returns the list of all dog breeds
// return {list} - a list of dog breed names as strings
function allDogBreeds(){
  return (getColumn("Dogs","Name"));
}



// Returns the URL of a random dog picture
// return {string} - the URL of a random dog image
function randomImage(){
  return (dogBreedImage(randomDogBreed()));
}



// Returns the URL of a random dog purpose
// return {string} - the URL of a random dog purpose
function randomPurpose(){
  return (breedsPurpose(randomDogBreed()));
}


//Tests program

console.log(randomDogBreed());
console.log(dogBreedImage("German Shepherd Dog"	));
console.log(breedsPurpose("German Shepherd Dog"	));
console.log(allDogBreeds());
console.log(randomImage());
console.log(randomPurpose());
