// Returns the name of a random art work by Bob Ross
// return {string} - the name of a random art work
function randomArtName(){
  var artWorkName = getColumn("Artistic Works of Bob Ross","TITLE");
  return (artWorkName[(randomNumber(0,artWorkName.length-1))]);
}

// Returns the image of a given art piece by Bob Ross
// searchArt {string} - the name of the art piece to search for
function artWork(searchArt){
  var artWorkName    = getColumn("Artistic Works of Bob Ross", "TITLE");
  var artWorkImage    = getColumn("Artistic Works of Bob Ross", "IMAGE");
  var image;
  
  for(var i=0; i<artWorkName.length; i++){
    if(artWorkName[i] == searchArt){
      image = artWorkImage[i];
    }
  }
  
  return image;
}


// Returns the name of a random Bob Ross episode
// return {string} - the name of a random Bob Ross episode
function randomEpisode(){
  var bobRossEpisode = getColumn("Artistic Works of Bob Ross","EPISODE");
  return (bobRossEpisode[(randomNumber(0,bobRossEpisode.length-1))]);
}


// Returns the list of all art pieces
// return {list} - a list of art piece names as strings
function allArtPieces(){
  return (getColumn("Artistic Works of Bob Ross","TITLE"));
}



// Returns the list of all episodes
// return {list} - a list of all episodes as strings
function allEpisodes(){
  return (getColumn("Artistic Works of Bob Ross","EPISODE"));
}

//Tests program

//Return True
//console.log(allArtPieces());
//console.log(allEpisodes());
//console.log(randomEpisode());
//console.log(randomArtName() );
//console.log(artWork("BLACK & WHITE SEASCAPE"	));

//Return False
//console.log(artWork("BLACK SEASCAPE"	));
