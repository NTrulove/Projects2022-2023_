//click monstersButton to get to Monsters screen 
onEvent("monstersButton", "click", function( ) {
  playSound("assets/category_animals/dinosaur.mp3", false);
  setScreen("Monsters1");
});
//click areasButton to get to the Areas screen
onEvent("areasButton", "click", function( ) {
  playSound("assets/category_nature/forest_woodland_loop.mp3", false);
  setScreen("backgroundAreas");
});
// click weaponsButton to get to Weapons screen
onEvent("weaponsButton", "click", function( ) {
  playSound("assets/category_swish/heavy_axe_swing.mp3", false);
  setScreen("weaponsScreen");
});
//Click homeButton3 to get to Home screen
onEvent("homeButton3", "click", function( ) {
  playSound("assets/category_app/arcade_game_button_tap.mp3", false);
  setScreen("homePage");
});
//Click homeButton2 to get to Home screen
onEvent("homeButton2", "click", function( ) {
  playSound("assets/category_app/arcade_game_button_tap.mp3", false);
  setScreen("homePage");
});
//Click homeButton1 to get to Home screen
onEvent("homeButton1", "click", function( ) {
  playSound("assets/category_app/arcade_game_button_tap.mp3", false);
  setScreen("homePage");
});
//Click backButton to get to previous screen
onEvent("backButton", "click", function( ) {
  playSound("assets/category_app/arcade_game_button_tap.mp3", false);
  setScreen("backgroundAreas");
});
onEvent("BackButton1", "click", function( ) {
  playSound("assets/category_app/arcade_game_button_tap.mp3", false);
  setScreen("Monsters1");
});
//clicking the next button will take you to the next screen
onEvent("nextPage1", "click", function( ) {
  playSound("assets/category_app/arcade_game_button_tap.mp3", false);
  setScreen("weaponsScreen");
});
onEvent("nextButton1", "click", function( ) {
  playSound("assets/category_app/arcade_game_button_tap.mp3", false);
  setScreen("backgroundAreas");
});
//Clicking any of the drop down buttons will play a sound
onEvent("dualwieldList", "click", function( ) {
  playSound("assets/category_swish/double_sword_swish.mp3", false);
});
onEvent("bladedList", "click", function( ) {
  playSound("assets/category_whoosh/sharp_sword_whoosh_1.mp3", false);
});
onEvent("nonbladedList", "click", function( ) {
  playSound("assets/category_hits/retro_game_simple_impact_2.mp3", false);
});
onEvent("rangedList", "click", function( ) {
  playSound("assets/category_swish/arrow_fly_pass_by_3.mp3", false);
});
onEvent("weaponsList", "click", function( ) {
  playSound("assets/category_swish/weapon_swing.mp3", false);
});
